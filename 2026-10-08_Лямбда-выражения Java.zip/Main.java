import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Organisation organisation = new Organisation();

        System.out.println("Все сотрудники:");
        organisation.printEmployees(employee -> true);

        System.out.println("Сотрудники младше 30 лет:");
        organisation.printEmployees(employee -> employee.age < 30);

        System.out.println("Сотрудники с зарплатой 50 и выше:");
        organisation.printEmployees(employee -> employee.salary >= 50);

        System.out.println("Сотрудники, чьё имя начинается на «А»:");
        organisation.printEmployees(employee -> employee.name.toLowerCase().startsWith("а"));
    }

    @FunctionalInterface
    interface EmployeeFilter {
        boolean accept(Employee employee);
    }

    static class Employee {
        final String name;
        final int age;
        final int salary;

        Employee(String name, int age, int salary) {
            this.name = name;
            this.age = age;
            this.salary = salary;
        }

        @Override
        public String toString() {
            return name + ", возраст " + age + ", зарплата " + salary;
        }
    }

    static class Organisation {
        private final List<Employee> employees = new ArrayList<>();

        Organisation() {
            employees.add(new Employee("Иван", 20, 33));
            employees.add(new Employee("Анна", 41, 58));
            employees.add(new Employee("Михаил", 30, 41));
            employees.add(new Employee("Екатерина", 23, 38));
            employees.add(new Employee("Александра", 38, 50));
            employees.add(new Employee("Сергей", 31, 30));
            employees.add(new Employee("Мария", 23, 33));
        }

        void printEmployees(EmployeeFilter filter) {
            for (Employee employee : employees) {
                if (filter.accept(employee)) {
                    System.out.println(employee);
                }
            }
            System.out.println();
        }
    }
}
