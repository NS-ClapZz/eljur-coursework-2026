import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.time.LocalDate;

/** Variant 29: a small in-memory task manager with CSV persistence. */
public class TaskManagerApp {
    private static final Scanner INPUT = new Scanner(System.in);
    private static final TaskManager MANAGER = new TaskManager();
    private static final Logger LOGGER = new Logger();

    public static void main(String[] args) {
        if (new File("tasks.csv").isFile()) MANAGER.load("tasks.csv");
        else seed();
        boolean running = true;
        while (running) {
            System.out.println("\n=== MINI JIRA ===\n1. Задачи\n2. Отчёты\n3. Сохранить\n0. Выход");
            int choice = readInt("Выбор: ");
            if (choice == 1) taskMenu();
            else if (choice == 2) reports();
            else if (choice == 3) MANAGER.save("tasks.csv");
            else if (choice == 0) { MANAGER.save("tasks.csv"); running = false; }
            else System.out.println("Нет такого пункта меню.");
        }
    }

    private static void taskMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n1. Список\n2. Создать задачу\n3. Найти задачу\n4. Изменить задачу\n5. Удалить задачу\n6. Сменить статус\n7. Добавить комментарий\n8. Назначить исполнителя\n9. Сортировка по приоритету\n10. Добавить зависимость\n11. Сортировка по названию\n12. Фильтр\n0. Назад");
            int c = readInt("Выбор: ");
            if (c == 1) MANAGER.printTasks();
            else if (c == 2) createTask();
            else if (c == 3) findTask();
            else if (c == 4) editTask();
            else if (c == 5) deleteTask();
            else if (c == 6) changeStatus();
            else if (c == 7) addComment();
            else if (c == 8) assign();
            else if (c == 9) MANAGER.sortByPriority();
            else if (c == 10) addDependency();
            else if (c == 11) MANAGER.sortByTitle();
            else if (c == 12) filterTasks();
            else if (c == 0) back = true;
            else System.out.println("Нет такого пункта меню.");
        }
    }

    private static void createTask() {
        try {
            String title = readLine("Название: ");
            String description = readLine("Описание: ");
            System.out.println("Тип: 1-Bug, 2-Feature, 3-Chore");
            int type = readInt("Тип: ");
            int priority = readInt("Приоритет (1-5): ");
            Task task;
            if (type == 1) task = new Bug(MANAGER.nextId(), title, description, priority);
            else if (type == 2) task = new Feature(MANAGER.nextId(), title, description, priority);
            else if (type == 3) task = new Chore(MANAGER.nextId(), title, description, priority);
            else throw new IllegalArgumentException("Неизвестный тип.");
            task.setDueDate(readLine("Срок (ГГГГ-ММ-ДД): "));
            MANAGER.add(task);
        } catch (IllegalArgumentException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void changeStatus() {
        try {
            int id = readInt("ID задачи: ");
            System.out.println("Статус: 1-Открыта, 2-В работе, 3-На проверке, 4-Закрыта");
            Status status = Status.fromCode(readInt("Новый статус: "));
            MANAGER.changeStatus(id, status);
        } catch (RuntimeException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void findTask() {
        String query = readLine("Введите ID или часть названия: ");
        try {
            int id = Integer.parseInt(query);
            Task task = MANAGER.find(id);
            if (task == null) System.out.println("Задача не найдена.");
            else System.out.println(task);
        } catch (NumberFormatException ex) { MANAGER.findByTitle(query); }
    }

    private static void editTask() {
        try {
            int id = readInt("ID задачи: ");
            MANAGER.editTask(id, readLine("Новое название (пусто — оставить): "),
                    readLine("Новое описание (пусто — оставить): "),
                    readLine("Новый приоритет 1–5 (пусто — оставить): "),
                    readLine("Новый срок ГГГГ-ММ-ДД (пусто — оставить): "));
        } catch (RuntimeException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void deleteTask() {
        try { MANAGER.deleteTask(readInt("ID задачи: ")); }
        catch (RuntimeException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void addComment() {
        try { MANAGER.addComment(readInt("ID задачи: "), readLine("Автор: "), readLine("Текст: ")); }
        catch (RuntimeException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void assign() {
        try { MANAGER.assign(readInt("ID задачи: "), readLine("Исполнитель: ")); }
        catch (RuntimeException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void addDependency() {
        try { MANAGER.addDependency(readInt("ID зависимой задачи: "), readInt("ID предшественника: ")); }
        catch (RuntimeException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void filterTasks() {
        System.out.println("Фильтр: 1-Статус, 2-Приоритет, 3-Просроченные");
        int kind = readInt("Тип фильтра: ");
        try {
            if (kind == 1) { System.out.println("Статус: 1-Открыта, 2-В работе, 3-На проверке, 4-Закрыта"); MANAGER.filterByStatus(Status.fromCode(readInt("Статус: "))); }
            else if (kind == 2) MANAGER.filterByPriority(Priority.fromRank(readInt("Приоритет (1-5): ")));
            else if (kind == 3) MANAGER.printOverdue();
            else System.out.println("Нет такого фильтра.");
        } catch (RuntimeException ex) { System.out.println("Ошибка: " + ex.getMessage()); }
    }

    private static void reports() {
        MANAGER.reportByStatus();
        MANAGER.reportByAssignee();
        MANAGER.reportPriority();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();
            try { return Integer.parseInt(value); }
            catch (NumberFormatException ex) { System.out.println("Введите целое число."); }
        }
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        return INPUT.nextLine().trim();
    }

    private static void seed() {
        for (int i = 1; i <= 15; i++) {
            Task task;
            if (i % 3 == 0) task = new Bug(i, "Дефект " + i, "Демонстрационная задача", i % 5 + 1);
            else if (i % 3 == 1) task = new Feature(i, "Функция " + i, "Демонстрационная задача", i % 5 + 1);
            else task = new Chore(i, "Работа " + i, "Демонстрационная задача", i % 5 + 1);
            task.setDueDate(LocalDate.now().plusDays(i % 7 - 2).toString());
            MANAGER.addSeed(task);
            if (i % 4 == 0) task.setAssignee("Исполнитель " + ((i % 3) + 1));
        }
    }

    private enum Status {
        OPEN(1, "Открыта"), IN_PROGRESS(2, "В работе"), REVIEW(3, "На проверке"), CLOSED(4, "Закрыта");
        private final int code; private final String label;
        Status(int code, String label) { this.code = code; this.label = label; }
        public int code() { return code; }
        public String toString() { return label; }
        static Status fromCode(int code) {
            for (Status s : values()) if (s.code == code) return s;
            throw new IllegalArgumentException("Статус должен быть от 1 до 4.");
        }
    }

    private enum Priority {
        TRIVIAL(1, "Низкий"), LOW(2, "Ниже среднего"), NORMAL(3, "Обычный"), HIGH(4, "Высокий"), CRITICAL(5, "Критический");
        private final int rank; private final String label;
        Priority(int rank, String label) { this.rank = rank; this.label = label; }
        public int rank() { return rank; }
        public String toString() { return label; }
        static Priority fromRank(int rank) {
            if (rank < 1 || rank > 5) throw new IllegalArgumentException("Приоритет должен быть от 1 до 5.");
            return values()[rank - 1];
        }
    }

    private interface TaskComparator { int compare(Task left, Task right); }
    private interface TaskAction { boolean accept(Task task); }
    private interface TaskMetric { String category(); }

    private abstract static class Task {
        private final int id; private String title; private String description;
        private Status status; private Priority priority; private String assignee;
        private final Comment[] comments = new Comment[20]; private int commentCount;
        private final int[] dependencies = new int[10]; private int dependencyCount;
        private LocalDate dueDate;
        Task(int id, String title, String description, int priority) {
            if (id <= 0) throw new IllegalArgumentException("ID должен быть положительным.");
            this.id = id; setTitle(title); setDescription(description);
            this.status = Status.OPEN; this.priority = Priority.fromRank(priority); this.assignee = "Не назначен";
            this.dueDate = LocalDate.now().plusDays(7);
        }
        public int id() { return id; }
        public String title() { return title; }
        public Status status() { return status; }
        public Priority priority() { return priority; }
        public String description() { return description; }
        public String assignee() { return assignee; }
        public LocalDate dueDate() { return dueDate; }
        void setTitle(String value) { if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Название не может быть пустым."); title = value.trim(); }
        void setDescription(String value) { if (value == null) throw new IllegalArgumentException("Описание обязательно."); description = value.trim(); }
        void setAssignee(String value) { if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Исполнитель обязателен."); assignee = value.trim(); }
        void setPriority(int value) { priority = Priority.fromRank(value); }
        void setDueDate(String value) { try { dueDate = LocalDate.parse(value.trim()); } catch (RuntimeException ex) { throw new IllegalArgumentException("Срок укажите в формате ГГГГ-ММ-ДД."); } }
        void setStatus(Status next) {
            boolean ok = (status == Status.OPEN && next == Status.IN_PROGRESS)
                    || (status == Status.IN_PROGRESS && (next == Status.REVIEW || next == Status.OPEN))
                    || (status == Status.REVIEW && (next == Status.CLOSED || next == Status.IN_PROGRESS));
            if (!ok) throw new InvalidTransitionException("Недопустимый переход: " + status + " → " + next);
            status = next;
        }
        abstract String type();
        abstract int estimate();
        void addComment(Comment comment) {
            if (commentCount == comments.length) throw new IllegalStateException("Достигнут лимит комментариев.");
            comments[commentCount++] = comment;
        }
        String csv() {
            StringBuilder ids = new StringBuilder();
            for (int i = 0; i < dependencyCount; i++) { if (i > 0) ids.append(','); ids.append(dependencies[i]); }
            return type() + ";" + id + ";" + clean(title) + ";" + clean(description) + ";" + status.code() + ";" + priority.rank() + ";" + clean(assignee) + ";" + dueDate + ";" + ids;
        }
        private static String clean(String s) { return s.replace(";", ",").replace("\n", " "); }
        public String toString() { return String.format("%-4d %-8s %-28s %-14s %-15s %-15s %s", id, type(), title, status, priority, dueDate, assignee); }
        public boolean equals(Object other) { return other instanceof Task && ((Task)other).id == id; }
        public int hashCode() { return id; }
    }

    private static final class Bug extends Task implements TaskMetric {
        Bug(int id, String title, String description, int priority) { super(id, title, description, priority); }
        String type() { return "BUG"; } int estimate() { return 3; }
        public String category() { return "Исправление дефекта"; }
    }
    private static final class Feature extends Task implements TaskMetric {
        Feature(int id, String title, String description, int priority) { super(id, title, description, priority); }
        String type() { return "FEATURE"; } int estimate() { return 5; }
        public String category() { return "Новая функция"; }
    }
    private static final class Chore extends Task implements TaskMetric {
        Chore(int id, String title, String description, int priority) { super(id, title, description, priority); }
        String type() { return "CHORE"; } int estimate() { return 2; }
        public String category() { return "Техническая работа"; }
    }

    private static final class Comment {
        private final String author; private final String text;
        Comment(String author, String text) {
            if (author == null || author.trim().isEmpty() || text == null || text.trim().isEmpty()) throw new IllegalArgumentException("Автор и текст комментария обязательны.");
            this.author = author.trim(); this.text = text.trim();
        }
        public String toString() { return author + ": " + text; }
    }
    private static final class User {
        private final String name;
        User(String name) { if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Имя обязательно."); this.name = name.trim(); }
        String name() { return name; }
        public String toString() { return name; }
    }
    private static final class Project {
        private final String name; private final String key;
        Project(String name, String key) { this.name = name; this.key = key; }
        public String toString() { return key + " — " + name; }
    }
    private static final class Sprint {
        private final String name; private final int capacity;
        Sprint(String name, int capacity) { this.name = name; this.capacity = capacity; }
        public String toString() { return name + " (ёмкость " + capacity + ")"; }
    }
    private static final class InvalidTransitionException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        InvalidTransitionException(String message) { super(message); }
    }
    private static final class CyclicDependencyException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        CyclicDependencyException(String message) { super(message); }
    }
    private static final class DataFormatException extends Exception {
        private static final long serialVersionUID = 1L;
        DataFormatException(String message) { super(message); }
    }

    private static final class TaskManager {
        private Task[] tasks = new Task[8]; private int size; private int sequence = 100;
        private final Project project = new Project("Учебный проект", "EDU");
        private final Sprint sprint = new Sprint("Спринт 1", 30);
        private final User[] users = { new User("Алексей"), new User("Мария"), new User("Иван") };
        
        int nextId() { return sequence++; }
        void addSeed(Task t) { addInternal(t); }
        void add(Task t) { addInternal(t); LOGGER.record("Создана задача " + t.id()); System.out.println("Создана задача " + t.id()); }
        private void addInternal(Task task) {
            if (find(task.id()) != null) return;
            if (size == tasks.length) { Task[] bigger = new Task[tasks.length * 2]; System.arraycopy(tasks, 0, bigger, 0, size); tasks = bigger; }
            tasks[size++] = task;
        }
        Task find(int id) { for (int i = 0; i < size; i++) if (tasks[i].id() == id) return tasks[i]; return null; }
        void findByTitle(String query) {
            String normalized = query.toLowerCase();
            boolean found = false;
            for (int i = 0; i < size; i++) if (tasks[i].title().toLowerCase().contains(normalized)) { System.out.println(tasks[i]); found = true; }
            if (!found) System.out.println("Задачи не найдены.");
        }
        void editTask(int id, String title, String description, String priorityText, String dueDate) {
            Task task = require(id);
            Integer priority = priorityText.isEmpty() ? null : Integer.valueOf(priorityText);
            if (priority != null) Priority.fromRank(priority);
            if (!dueDate.isEmpty()) LocalDate.parse(dueDate);
            if (!title.isEmpty()) task.setTitle(title);
            if (!description.isEmpty()) task.setDescription(description);
            if (priority != null) task.setPriority(priority);
            if (!dueDate.isEmpty()) task.setDueDate(dueDate);
            LOGGER.record("Изменена задача " + id);
            System.out.println("Изменения сохранены.");
        }
        void deleteTask(int id) {
            require(id);
            for (int i = 0; i < size; i++) if (tasks[i].id() == id) {
                for (int j = i; j < size - 1; j++) tasks[j] = tasks[j + 1];
                tasks[--size] = null;
                LOGGER.record("Удалена задача " + id);
                System.out.println("Задача удалена.");
                return;
            }
        }
        void changeStatus(int id, Status status) {
            Task t = require(id);
            if (status == Status.CLOSED) for (int i = 0; i < t.dependencyCount; i++) if (require(t.dependencies[i]).status() != Status.CLOSED) throw new InvalidTransitionException("Сначала закройте все задачи-зависимости.");
            t.setStatus(status); LOGGER.record("Статус задачи " + id + ": " + status);
        }
        void assign(int id, String name) { Task t = require(id); t.setAssignee(new User(name).name()); LOGGER.record("Назначен исполнитель задачи " + id); }
        void addComment(int id, String author, String text) { require(id).addComment(new Comment(author, text)); LOGGER.record("Комментарий к задаче " + id); }
        void addDependency(int id, int predecessorId) {
            Task task = require(id); require(predecessorId);
            if (id == predecessorId || reaches(predecessorId, id, new boolean[sequence + size + 100])) throw new CyclicDependencyException("Зависимость создаёт цикл.");
            for (int i = 0; i < task.dependencyCount; i++) if (task.dependencies[i] == predecessorId) return;
            if (task.dependencyCount == task.dependencies.length) throw new IllegalStateException("Достигнут лимит зависимостей.");
            task.dependencies[task.dependencyCount++] = predecessorId; LOGGER.record("Добавлена зависимость " + id + " -> " + predecessorId);
        }
        private boolean reaches(int from, int target, boolean[] visited) {
            if (from == target) return true;
            if (from < 0 || from >= visited.length || visited[from]) return false;
            visited[from] = true; Task current = find(from); if (current == null) return false;
            for (int i = 0; i < current.dependencyCount; i++) if (reaches(current.dependencies[i], target, visited)) return true;
            return false;
        }
        private Task require(int id) { Task t = find(id); if (t == null) throw new IllegalArgumentException("Задача не найдена."); return t; }
        void printTasks() {
            System.out.println(project + " / " + sprint);
            System.out.printf("%-4s %-8s %-28s %-14s %-15s %-15s %s%n", "ID", "Тип", "Название", "Статус", "Приоритет", "Срок", "Исполнитель");
            for (int i = 0; i < size; i++) System.out.println(tasks[i]);
        }
        void sortByTitle() { sort(new TaskComparator() { public int compare(Task a, Task b) { return a.title().compareToIgnoreCase(b.title()); } }); printTasks(); }
        void sortByPriority() {
            sort(new TaskComparator() { public int compare(Task a, Task b) { return b.priority().rank() - a.priority().rank(); } });
            printTasks();
        }
        void filterByStatus(Status status) { printMatching(new TaskAction() { public boolean accept(Task t) { return t.status() == status; } }); }
        void filterByPriority(Priority priority) { printMatching(new TaskAction() { public boolean accept(Task t) { return t.priority() == priority; } }); }
        void printOverdue() { printMatching(new TaskAction() { public boolean accept(Task t) { return t.status() != Status.CLOSED && t.dueDate().isBefore(LocalDate.now()); } }); }
        private void printMatching(TaskAction action) {
            System.out.printf("%-4s %-8s %-28s %-14s %-15s %-15s %s%n", "ID", "Тип", "Название", "Статус", "Приоритет", "Срок", "Исполнитель");
            for (int i = 0; i < size; i++) if (action.accept(tasks[i])) System.out.println(tasks[i]);
        }
        private void sort(TaskComparator cmp) {
            for (int i = 1; i < size; i++) { Task key = tasks[i]; int j = i - 1; while (j >= 0 && cmp.compare(tasks[j], key) > 0) { tasks[j + 1] = tasks[j]; j--; } tasks[j + 1] = key; }
        }
        void reportByStatus() {
            System.out.println("\nЗадачи по статусам");
            for (Status s : Status.values()) { int count = 0; for (int i = 0; i < size; i++) if (tasks[i].status() == s) count++; System.out.printf("%-14s %3d%n", s, count); }
        }
        void reportByAssignee() {
            System.out.println("\nЗадачи по исполнителям");
            String[] names = new String[size]; int[] counts = new int[size]; int n = 0;
            for (int i = 0; i < size; i++) { String who = tasks[i].assignee(); int k = 0; while (k < n && !names[k].equals(who)) k++; if (k == n) names[n++] = who; counts[k]++; }
            for (int i = 0; i < n; i++) System.out.printf("%-20s %3d%n", names[i], counts[i]);
        }
        void reportPriority() {
            int total = 0, open = 0, closed = 0; Task top = null;
            for (int i = 0; i < size; i++) { total += tasks[i].estimate(); if (tasks[i].status() != Status.CLOSED) open++; else closed++; if (top == null || tasks[i].priority().rank() > top.priority().rank()) top = tasks[i]; }
            System.out.println("\nСводка: задач " + size + ", открытых " + open + ", закрытых " + closed + ", оценка " + total + " баллов.");
            if (top != null) System.out.println("Высший приоритет: " + top);
        }
        void save(String path) {
            try (PrintWriter out = new PrintWriter(new FileWriter(path))) { for (int i = 0; i < size; i++) out.println(tasks[i].csv()); LOGGER.record("Сохранены задачи в " + path); }
            catch (IOException ex) { System.out.println("Не удалось сохранить файл: " + ex.getMessage()); }
        }
        void load(String path) {
            File file = new File(path); if (!file.exists()) return;
            try (BufferedReader in = new BufferedReader(new FileReader(file))) {
                String line; while ((line = in.readLine()) != null) try { parse(line); } catch (DataFormatException | RuntimeException ex) { System.out.println("Строка пропущена: " + ex.getMessage()); }
            } catch (IOException ex) { System.out.println("Не удалось прочитать файл: " + ex.getMessage()); }
        }
        private void parse(String line) throws DataFormatException {
            String[] p = line.split(";", -1); if (p.length != 9) throw new DataFormatException("ожидалось 9 полей");
            int id = Integer.parseInt(p[1]); Task t;
            if (p[0].equals("BUG")) t = new Bug(id, p[2], p[3], Integer.parseInt(p[5]));
            else if (p[0].equals("FEATURE")) t = new Feature(id, p[2], p[3], Integer.parseInt(p[5]));
            else if (p[0].equals("CHORE")) t = new Chore(id, p[2], p[3], Integer.parseInt(p[5]));
            else throw new DataFormatException("неизвестный тип");
            if (find(id) != null) return;
            t.status = Status.fromCode(Integer.parseInt(p[4])); t.setAssignee(p[6]); t.setDueDate(p[7]); addInternal(t); if (id >= sequence) sequence = id + 1;
            if (!p[8].isEmpty()) { String[] deps = p[8].split(","); for (String dep : deps) { int depId = Integer.parseInt(dep); if (depId == id) throw new DataFormatException("зависимость на саму себя"); if (t.dependencyCount < t.dependencies.length) t.dependencies[t.dependencyCount++] = depId; } }
        }
    }

    private static final class Logger {
        private String[] entries = new String[32];
        private int size;
        void record(String event) {
            String entry = java.time.LocalDateTime.now() + " | " + event;
            if (size == entries.length) {
                String[] expanded = new String[entries.length * 2];
                System.arraycopy(entries, 0, expanded, 0, size);
                entries = expanded;
            }
            entries[size++] = entry;
            try (PrintWriter out = new PrintWriter(new FileWriter("log.txt", true))) { out.println(entry); }
            catch (IOException ex) { System.out.println("Не удалось записать журнал: " + ex.getMessage()); }
        }
    }
}
