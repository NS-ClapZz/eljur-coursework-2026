#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <iostream>
#include <limits>
#include <string>

namespace {
HANDLE inputHandle() { return GetStdHandle(STD_INPUT_HANDLE); }
HANDLE outputHandle() { return GetStdHandle(STD_OUTPUT_HANDLE); }

void writeLine(HANDLE handle, const std::wstring& text) {
    DWORD written = 0;
    if (!WriteConsoleW(handle, text.c_str(), static_cast<DWORD>(text.size()), &written, nullptr))
        std::wcerr << L"WriteConsoleW завершилась ошибкой: " << GetLastError() << L"\n";
}

bool readLine(HANDLE handle, std::wstring& text) {
    wchar_t buffer[256]{};
    DWORD read = 0;
    if (!ReadConsoleW(handle, buffer, 255, &read, nullptr)) {
        std::wcerr << L"ReadConsoleW завершилась ошибкой: " << GetLastError() << L"\n";
        return false;
    }
    text.assign(buffer, read);
    while (!text.empty() && (text.back() == L'\r' || text.back() == L'\n')) text.pop_back();
    return true;
}

void createAndActivateBuffer() {
    HANDLE oldBuffer = outputHandle();
    HANDLE newBuffer = CreateConsoleScreenBuffer(
        GENERIC_READ | GENERIC_WRITE, 0, nullptr, CONSOLE_TEXTMODE_BUFFER, nullptr);
    if (newBuffer == INVALID_HANDLE_VALUE) {
        std::wcerr << L"Не удалось создать буфер: " << GetLastError() << L"\n";
        return;
    }
    if (!SetConsoleActiveScreenBuffer(newBuffer)) {
        std::wcerr << L"Не удалось активировать буфер: " << GetLastError() << L"\n";
        CloseHandle(newBuffer);
        return;
    }
    writeLine(newBuffer, L"Новый буфер экрана активен.\r\nНажмите Enter, чтобы вернуться к исходному буферу.\r\n");
    std::wstring ignored;
    readLine(inputHandle(), ignored);
    if (!SetConsoleActiveScreenBuffer(oldBuffer))
        std::wcerr << L"Не удалось восстановить исходный буфер: " << GetLastError() << L"\n";
    else
        writeLine(oldBuffer, L"Исходный буфер восстановлен.\r\n");
    CloseHandle(newBuffer);
}

void showBufferInfo() {
    CONSOLE_SCREEN_BUFFER_INFO info{};
    if (!GetConsoleScreenBufferInfo(outputHandle(), &info)) {
        std::wcerr << L"GetConsoleScreenBufferInfo: " << GetLastError() << L"\n";
        return;
    }
    std::wcout << L"Размер: " << info.dwSize.X << L" столбцов × " << info.dwSize.Y << L" строк\n"
               << L"Курсор: (" << info.dwCursorPosition.X << L", " << info.dwCursorPosition.Y << L")\n"
               << L"Атрибуты текста: 0x" << std::hex << info.wAttributes << std::dec << L"\n"
               << L"Окно: left=" << info.srWindow.Left << L", top=" << info.srWindow.Top
               << L", right=" << info.srWindow.Right << L", bottom=" << info.srWindow.Bottom << L"\n"
               << L"Максимальный размер окна: " << info.dwMaximumWindowSize.X << L" × " << info.dwMaximumWindowSize.Y << L"\n";
}

void resizeBuffer() {
    CONSOLE_SCREEN_BUFFER_INFO info{};
    if (!GetConsoleScreenBufferInfo(outputHandle(), &info)) {
        std::wcerr << L"GetConsoleScreenBufferInfo: " << GetLastError() << L"\n";
        return;
    }
    int columns = 0, rows = 0;
    std::wcout << L"Новый размер буфера (столбцы строки): ";
    if (!(std::wcin >> columns >> rows) || columns < 1 || rows < 1 || columns > 32767 || rows > 32767) {
        std::wcin.clear(); std::wcin.ignore((std::numeric_limits<std::streamsize>::max)(), L'\n');
        std::wcerr << L"Введите положительные размеры не больше 32767.\n";
        return;
    }
    std::wcin.ignore((std::numeric_limits<std::streamsize>::max)(), L'\n');
    const int windowWidth = info.srWindow.Right - info.srWindow.Left + 1;
    const int windowHeight = info.srWindow.Bottom - info.srWindow.Top + 1;
    if (columns < windowWidth || rows < windowHeight) {
        std::wcerr << L"Размер буфера не может быть меньше текущего окна (" << windowWidth << L" × " << windowHeight << L").\n";
        return;
    }
    COORD size{ static_cast<SHORT>(columns), static_cast<SHORT>(rows) };
    if (!SetConsoleScreenBufferSize(outputHandle(), size))
        std::wcerr << L"SetConsoleScreenBufferSize: " << GetLastError() << L"\n";
    else
        std::wcout << L"Размер буфера изменён.\n";
}

void readAndWriteConsole() {
    const std::wstring prompt = L"Введите строку: ";
    DWORD written = 0;
    if (!WriteConsoleW(outputHandle(), prompt.c_str(), static_cast<DWORD>(prompt.size()), &written, nullptr)) {
        std::wcerr << L"WriteConsoleW: " << GetLastError() << L"\n"; return;
    }
    std::wstring text;
    if (!readLine(inputHandle(), text)) return;
    writeLine(outputHandle(), L"Вы ввели: " + text + L"\r\n");
}

void showTextColors() {
    HANDLE out = outputHandle();
    CONSOLE_SCREEN_BUFFER_INFO info{};
    if (!GetConsoleScreenBufferInfo(out, &info)) return;
    const WORD colors[] = { FOREGROUND_RED | FOREGROUND_INTENSITY,
                            FOREGROUND_GREEN | FOREGROUND_INTENSITY,
                            FOREGROUND_BLUE | FOREGROUND_INTENSITY,
                            FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY };
    const wchar_t* labels[] = { L"Красный текст", L"Зелёный текст", L"Синий текст", L"Жёлтый текст" };
    for (int i = 0; i < 4; ++i) {
        SetConsoleTextAttribute(out, static_cast<WORD>((info.wAttributes & 0xF0) | colors[i]));
        writeLine(out, std::wstring(labels[i]) + L"\r\n");
    }
    SetConsoleTextAttribute(out, info.wAttributes);
}

void showMenu() {
    std::wcout << L"\n=== Работа с буфером экрана ===\n"
               << L"1. Создать и активировать новый буфер\n"
               << L"2. Показать сведения о буфере\n"
               << L"3. Изменить размер буфера\n"
               << L"4. Прочитать и вывести строку через ReadConsole/WriteConsole\n"
               << L"5. Показать атрибуты цветов текста\n"
               << L"0. Выход\nВыбор: ";
}
}

int wmain() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    while (true) {
        showMenu();
        int choice = -1;
        if (!(std::wcin >> choice)) {
            std::wcin.clear();
            std::wcin.ignore((std::numeric_limits<std::streamsize>::max)(), L'\n');
            std::wcerr << L"Введите номер пункта меню.\n";
            continue;
        }
        std::wcin.ignore((std::numeric_limits<std::streamsize>::max)(), L'\n');
        switch (choice) {
        case 1: createAndActivateBuffer(); break;
        case 2: showBufferInfo(); break;
        case 3: resizeBuffer(); break;
        case 4: readAndWriteConsole(); break;
        case 5: showTextColors(); break;
        case 0: return 0;
        default: std::wcerr << L"Нет такого пункта меню.\n"; break;
        }
    }
}
